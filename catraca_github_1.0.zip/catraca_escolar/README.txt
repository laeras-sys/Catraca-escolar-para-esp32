CATRACA ESCOLAR INTELIGENTE — ESP32
Projeto de TCC

Autores:
- Leandro Augusto Trombini
- Sophia Gomes
- Leonardo La Eras
- Daniel Sotto
- Vinicius Miranda

Orientadores:
- Camilo Mesquita
- Mauricio Hilst

Revisão: 29/10/2026

1. O QUE O PROGRAMA FAZ

Identifica um aluno pelo cartão RFID, autoriza uma passagem e usa dois
sensores infravermelhos digitais para verificar a direção do movimento.
Somente uma passagem confirmada altera a presença e tenta gravar no SD.
Não utiliza botão de saída: o mesmo RFID identifica entradas e saídas.

O programa considera o aluno fora ou dentro a partir da última passagem
confirmada. Cartão de aluno fora autoriza entrada; cartão de aluno dentro
autoriza saída. Aproximar o cartão, sozinho, não registra uma passagem.

2. QUAL PACOTE USAR

catraca_uso_local.zip:
  Contém o código revisado e os arquivos privados com a rede e os alunos
  que já estavam no projeto. Extraia e abra o sketch dentro da pasta
  catraca_sd_hspi. Este ZIP contém dados privados: não o publique.

catraca_github.zip:
  Contém o mesmo código, documentação, testes e exemplos fictícios.
  Não contém senha, nome da rede doméstica ou cadastro real dos alunos.
  Este é o pacote preparado para o repositório público.

Os dois pacotes usam exatamente as mesmas conexões do projeto.

3. ORGANIZAÇÃO DOS ARQUIVOS

catraca_sd_hspi/catraca_sd_hspi.ino
  Programa principal: componentes, filtros, RFID, estados, SD e horário.

catraca_sd_hspi/rede_exemplo.h
  Modelo público com WIFI_SSID e WIFI_SENHA vazios.

catraca_sd_hspi/rede_local.h
  Configuração privada da rede. Tem prioridade sobre o exemplo quando
  está presente. O pacote de uso local já inclui a configuração anterior.

catraca_sd_hspi/alunos_exemplo.h
  Modelo público do array banco[], usando somente alunos fictícios.

catraca_sd_hspi/alunos_local.h
  Cadastro privado. Tem prioridade sobre o exemplo quando está presente.
  O pacote de uso local preserva os cinco cadastros anteriores.

README.txt e README.md
  Mesma documentação, em texto e em formato exibido pelo GitHub.

tests/
  Testes de lógica, CSV e horário executados no computador.

.gitignore
  Exclui configurações privadas, logs CSV e arquivos gerados do git add.
  Ao enviar arquivos manualmente pelo site, não envie os arquivos locais.
  Se um arquivo privado já foi publicado, o .gitignore não apaga o histórico.

4. CONEXÕES ATUAIS — MANTIDAS

RFID RC522, barramento SPI/VSPI:
  SS/CS/SDA do módulo .... GPIO 5
  RST ................... GPIO 27
  SCK ................... GPIO 18
  MISO .................. GPIO 19
  MOSI .................. GPIO 23
  VCC ................... 3,3 V
  GND ................... GND comum

LCD I2C 16x2, endereço 0x27:
  SDA ................... GPIO 21
  SCL ................... GPIO 22

Servo SG90:
  Sinal ................. GPIO 25
  Ângulo fechado ........ 0 graus
  Ângulo aberto ......... 90 graus

Sensores infravermelhos digitais:
  S1, lado de fora ...... GPIO 32
  S2, lado de dentro .... GPIO 33
  Detecção .............. LOW, após filtro de 40 ms

Módulo microSD, barramento exclusivo HSPI:
  CS .................... GPIO 13
  SCK ................... GPIO 14
  MOSI/DI ............... GPIO 26
  MISO/DO ............... GPIO 34
  Frequência SPI ........ 400 kHz
  VCC ................... 5 V no módulo com regulador AMS1117-3.3 usado
  GND ................... GND comum

O RC522 permanece em 3,3 V. A indicação de 5 V acima é para a alimentação
do adaptador SD usado pelo grupo, não para um cartão SD sem adaptador nem
para sinais do ESP32. As saídas dos sensores devem ser compatíveis com
3,3 V. GPIO 34 recebe MISO e funciona como entrada, como exigido aqui.
GPIO 25 é sinal de controle, não alimentação do servo.

O RFID continua nos GPIOs 18/19/23. O SD usa 14/34/26 em outra instância
SPIClass. Isso preserva a ligação que passou no diagnóstico de escrita
e leitura do cartão FAT32 de 8 GB usado pelo grupo.

5. COMO ABRIR E ENVIAR NA IDE ARDUINO

1) Extraia o pacote. Não tente abrir o sketch diretamente dentro do ZIP.
2) Abra catraca_sd_hspi/catraca_sd_hspi.ino. A pasta e o sketch devem
   continuar com o mesmo nome: catraca_sd_hspi.
3) Mantenha os arquivos .h dentro dessa mesma pasta.
4) Use o pacote de placas ESP32 da Espressif e selecione a placa/porta
   que já funcionaram com o projeto. Este código usa HSPI/VSPI do ESP32
   clássico; não presume que todas as variantes ESP32 tenham a mesma pinagem.
5) Mantenha as bibliotecas usadas pelo grupo: MFRC522, ESP32Servo e
   LiquidCrystal I2C com suporte a lcd.init(). WiFi, SPI, Wire, FS, SD e
   as funções de horário acompanham o ambiente Arduino-ESP32.
6) Envie o programa e abra o Monitor Serial em 115200 baud.

Se usar o pacote público, crie rede_local.h a partir de rede_exemplo.h
e alunos_local.h a partir de alunos_exemplo.h. Edite somente as cópias
locais. Sem elas, o programa compila com o cadastro fictício e fica offline.

Não há alteração de fios necessária para esta revisão.

6. COMO CADASTRAR ALUNOS E AJUSTAR A TURMA

Em alunos_local.h, cada linha do array banco[] contém:
  {"UID", "Nome", "RM", TURMA_PADRAO, ANO_LETIVO_PADRAO}

UID e RM são textos: mantenha as aspas e os zeros iniciais.
O UID deve estar em hexadecimal MAIÚSCULO e sem espaços. Não repita o
mesmo UID para dois alunos. O nome não identifica o cartão: o UID identifica.

Para descobrir um UID:
1) Mude MODO_LER_UIDS para true e envie o programa.
2) Aproxime um cartão e veja o UID e a linha de cadastro no Monitor Serial.
3) Preencha alunos_local.h.
4) Volte MODO_LER_UIDS para false e envie novamente.

No modo de leitura de UID, o controle normal fica desativado: o programa
não inicializa o SD, não comanda o servo e não grava passagens.

TURMA_PADRAO está definida como "3º Mecatrônica" e ANO_LETIVO_PADRAO como
"2026", no sketch. O ano letivo é um dado do cadastro, separado do ano da
data. Para outro ano letivo, atualize essa constante. Também é possível
preencher uma turma e um ano específicos em cada registro do cadastro.

7. SEQUÊNCIA COMPLETA DE UMA PASSAGEM

Entrada:
  Cartão cadastrado de aluno fora; sensores livres; servo abre.
  S1 detecta primeiro. S2 detecta depois. Os dois precisam ficar livres.
  O servo recebe o comando de fechar, o aluno passa a estar dentro e
  o sistema tenta acrescentar uma linha ENTRADA no SD.

Saída:
  Cartão cadastrado de aluno dentro; sensores livres; servo abre.
  S2 detecta primeiro. S1 detecta depois. Os dois precisam ficar livres.
  O servo recebe o comando de fechar, o aluno passa a estar fora e
  o sistema tenta acrescentar uma linha SAIDA no SD.

Aceita sensores com áreas sobrepostas:
  Primeiro ocupado; ambos ocupados; somente segundo ocupado; ambos livres.

Aceita sensores separados por um espaço:
  Primeiro ocupado; ambos livres; segundo ocupado; ambos livres.
  A fase intermediária com ambos livres não encerra a tentativa.

Rejeita segundo sensor antes do primeiro, ambos detectados inicialmente
sem ordem distinguível e padrões de recuo reconhecidos pela máquina de
estados. Um cartão desconhecido não abre a catraca. Sensores ocupados
impedem autorizar uma nova tentativa.

Durante uma tentativa, o programa não aceita outro cartão. Uma identidade
pendente corresponde a uma única passagem. Para reutilizar um cartão,
afaste-o do leitor e aproxime novamente depois de terminar a operação.

8. O PRAZO DE 10 SEGUNDOS

inicioOperacao recebe millis() quando o cartão válido é autorizado.
O prazo total é 10000 ms. Nenhum sensor renova esse prazo.

Exemplo: primeiro sensor aos 7 s e confirmação completa aos 9 s: pode
registrar. Primeiro sensor aos 7 s e conclusão aos 11 s: não registra.
Em 10000 ms o prazo expirou; a conclusão deve ocorrer antes desse limite.
Os 40 ms usados para estabilizar os sensores fazem parte desse prazo.

Não existe delay(10000). O loop continua lendo os sensores e comparando
o tempo decorrido. O tempo é conferido novamente imediatamente antes de
concluir, para impedir uma confirmação tardia.

Se o prazo terminar, a ordem estiver errada ou houver recuo reconhecido:
  - Não acrescenta registro de acesso no SD.
  - Não muda a presença nem a contagem.
  - Descarta a identidade pendente.
  - Se os sensores estiverem livres, fecha e mostra SEM REGISTRO.
  - Se estiverem ocupados, mantém aberto até ambos ficarem livres e só
    então fecha. Não aceita outra identificação durante essa espera.

Uma detecção posterior ao cancelamento não recupera a tentativa anterior.
Se um sensor ficar permanentemente ocupado, a espera para fechar também
permanece: o programa não força o fechamento ao atingir os 10 segundos.

9. COMO ENTENDER A MÁQUINA DE ESTADOS

ESPERANDO
  Lê cartões e pode autorizar uma tentativa.
AGUARDANDO_PRIMEIRO
  Espera o sensor do lado de origem, rejeitando o outro antes dele.
AGUARDANDO_SEGUNDO
  Primeiro foi detectado; espera o outro. Pode haver espaço entre sensores.
AGUARDANDO_LIBERAR_PRIMEIRO
  Ambos foram detectados; espera o primeiro liberar e observa recuo.
AGUARDANDO_LIBERAR_SEGUNDO
  Espera o último sensor liberar. Só confirma com ambos livres.
CANCELADO_AGUARDANDO_LIVRE
  Tentativa descartada; aguarda liberar para fechar, sem poder registrar.
MOSTRANDO_MENSAGEM
  Exibe resultado por 2 segundos antes de voltar a ler cartões.

EntradaFiltrada trata oscilações. estaAtiva() informa o nível estável;
ativou() informa apenas uma nova ativação naquela volta do loop.
estaLivre() exige nível filtrado e leitura bruta livres, estáveis por 40 ms.

10. WI-FI, DATA E HORA

Preencha WIFI_SSID e WIFI_SENHA em rede_local.h. A rede do projeto é
configurada no modo estação. O ESP32 clássico usa Wi-Fi de 2,4 GHz.
SSID vazio desativa a tentativa de conexão, permitindo uso local.

Ao conectar, o programa configura NTP com pool.ntp.org e time.nist.gov.
O fuso é Brasília, UTC-3, sem horário de verão nesta configuração.
Não aguarda a conexão para permitir que a catraca funcione.

DATA e HORA correspondem à passagem confirmada, não à leitura do cartão.
Sem relógio disponível, grava SEM_HORARIO nos dois campos e libera o
funcionamento normal. Registros antigos com SEM_HORARIO não são corrigidos
automaticamente depois de conectar.

Depois de sincronizado, o relógio continua enquanto a placa está alimentada,
mesmo com queda do Wi-Fi. Após desligar a alimentação, pode ser necessária
nova sincronização. O programa não usa um módulo RTC externo.

O callback do NTP apenas marca uma sinalização; as mensagens são tratadas
no loop, evitando manipular LCD e Serial de dentro da tarefa de rede.
millis() controla os prazos e time() fornece calendário: ajustar o relógio
pela internet não altera o prazo da passagem.

Os registros ficam no SD. Este código não envia dados de alunos à internet
e não implementa site, servidor ou banco de dados na nuvem.

11. COMO LER A TABELA DO SD

Arquivo de novos registros: /acessos_escolares.csv
Separador: ponto e vírgula. Codificação: UTF-8 com BOM no início do arquivo.

Cabeçalho:
TIPO;RM;NOME;TURMA;ANO_LETIVO;DATA;HORA;UID;DENTRO

Exemplo FICTÍCIO de entrada:
ENTRADA;000001;Aluno Exemplo 1;3º Mecatrônica;2026;29/10/2026;08:00:00;00000001;1

Exemplo FICTÍCIO sem horário:
SAIDA;000001;Aluno Exemplo 1;3º Mecatrônica;2026;SEM_HORARIO;SEM_HORARIO;00000001;0

TIPO indica ENTRADA ou SAIDA. DENTRO é a quantidade total de alunos
cadastrados considerados dentro depois daquele evento, não a turma.
Cada passagem confirmada acrescenta uma linha, sem apagar as anteriores.
Aspas e ponto e vírgula em nomes são escapados; quebras de linha do cadastro
são substituídas por espaços para manter uma passagem em cada linha.

Para consultar no computador, desligue a placa antes de retirar o cartão.
Abra o CSV no Excel ou LibreOffice Calc. Se aparecer em uma coluna, importe
como texto/CSV, escolhendo UTF-8 e ponto e vírgula como separador.
Importe UID e RM como texto para preservar zeros iniciais.

12. SD, FALHAS E RECUPERAÇÃO DA PRESENÇA

O SD é inicializado uma vez no setup, em HSPI e 400 kHz. O programa não
formata o cartão automaticamente. A gravação só acontece depois de fechar
a passagem confirmada; as tentativas canceladas não geram linha de acesso.

Antes de escrever, o programa confere o cabeçalho. Depois escreve, solicita
flush, fecha, reabre e compara o tamanho e todos os bytes da linha nova.
Somente depois dessa conferência anuncia que o registro foi salvo.
Essa conferência detecta falhas de gravação/leitura, mas não transforma o
SD em armazenamento imune a desligamento no meio de uma operação.

Ao iniciar, aplica /acessos.csv, se existir, e depois /acessos_escolares.csv.
O arquivo antigo de sete campos é preservado e não recebe novas linhas.
O histórico novo tem prioridade. Uma linha só altera a presença de um
cadastro cujo UID e RM coincidam; a última linha válida desse aluno vence.

Linhas inválidas, longas demais ou sem a quebra de linha final são ignoradas
na recuperação. O limite por linha é 1024 bytes, sem CR/LF, não 1024 letras.
Uma cauda interrompida recebe o marcador REGISTRO_INCOMPLETO antes da
próxima escrita para não se juntar ao novo registro. Ela não vira presença.

Se o SD falhar, a passagem confirmada ainda atualiza a presença na RAM e
o LCD mostra PASSAGEM OK / ERRO NO SD. Não há fila para gravar depois.
O programa não tenta remontar o SD durante o funcionamento: após corrigir
um erro do cartão, reinicie a placa. Não retire o SD com a placa ligada.

Sem histórico utilizável, os alunos começam como fora. Ao reiniciar após
uma passagem que não foi salva, a presença pode voltar ao último estado
gravado e a próxima direção escolhida pode precisar de correção pelo grupo.
Trocar o cadastro, editar ou apagar o CSV também altera essa recuperação.
Não existe reinicialização automática da presença a cada novo dia letivo.

13. O QUE FOI CORRIGIDO NESTA REVISÃO

a) Prazo usando um instante antigo:
   Antes, agora era lido antes de atualizar a rede. Um atraso nessa etapa
   podia permitir concluir depois do prazo. A amostragem vem depois da rede
   e existe uma última checagem de millis() junto à confirmação.

b) Mensagem de sucesso sem conferir o conteúdo persistido:
   Antes, contava os bytes aceitos por print() e chamava flush(), que não
   fornece resultado de sucesso. Agora fecha, reabre e confere a linha nova.
   Falha na releitura passa a ser erro no SD.

c) Fechamento no arranque depois da leitura do histórico:
   O comando inicial do servo agora vem antes de montar e percorrer o SD.
   Isso antecipa o comando; não garante fechamento mecânico instantâneo.

d) Proteções de tamanho e preparação para publicação:
   Cabeçalho corrompido não pode crescer a leitura sem limite. O gravador
   rejeita uma linha maior do que o restaurador aceita. Rede e cadastro real
   foram separados dos exemplos públicos. Pinos e dados locais preservados.

14. TESTES E ALCANCE DA REVISÃO

Os testes usam o código real com componentes simulados em C++. Verificam
entradas e saídas, sensores sobrepostos e separados, recuo, ordem errada,
ruído, timeout, limites de 9999/10000 ms, volta do contador millis(), SD com
escrita parcial ou perdida, releitura divergente e recuperação da presença.
Há testes separados para CSV, acentos, arquivos interrompidos, SEM_HORARIO
e conversão de data/hora para Brasília.

Para executar no computador, instale Python 3 e g++ com suporte a C++17.
Na pasta principal do projeto, execute:
  python3 tests/executar.py catraca_sd_hspi/catraca_sd_hspi.ino
  python3 tests/testar_csv.py
  python3 tests/testar_horario.py

Os testes não exigem alterar o sketch e não acessam um ESP32 conectado.
A verificação não substitui compilar na IDE e testar a revisão na montagem.
O comportamento mecânico, alimentação, alinhamento, pulsos curtos e
estabilidade real do Wi-Fi dependem do hardware e das bibliotecas instaladas.

Teste prático recomendado: uma entrada completa, uma saída completa,
cartão sem passagem por 10 segundos, primeiro sensor sem segundo, recuo,
passagem offline e reinício após um registro confirmado. Confira o CSV.

15. LIMITES DO PROTÓTIPO

Dois sensores informam uma sequência de ocupação; não identificam pessoas.
O sistema não garante que só uma pessoa passou, que o portador é o dono do
cartão ou que não houve acompanhante. Um padrão fisicamente ambíguo pode
ser indistinguível de uma passagem normal para apenas dois sensores.

O filtro de 40 ms e a leitura por polling podem perder pulsos muito curtos.
Bibliotecas e SD podem bloquear brevemente. O comando de fechar não mede
a posição real do servo e os sensores de passagem não são um sistema
certificado de proteção contra esmagamento. O conjunto é um protótipo de TCC.

16. REFERÊNCIAS TÉCNICAS

SPI e barramentos do Arduino-ESP32:
https://docs.espressif.com/projects/arduino-esp32/en/latest/api/spi.html

Biblioteca SD e exemplo oficial:
https://github.com/espressif/arduino-esp32/tree/master/libraries/SD

File, leitura, escrita e flush na implementação oficial:
https://github.com/espressif/arduino-esp32/blob/master/libraries/FS/src/FS.h
https://github.com/espressif/arduino-esp32/blob/master/libraries/FS/src/vfs_api.cpp

Wi-Fi do Arduino-ESP32:
https://docs.espressif.com/projects/arduino-esp32/en/latest/api/wifi.html

Exemplo oficial de horário/NTP:
https://github.com/espressif/arduino-esp32/blob/master/libraries/ESP32/examples/Time/SimpleTime/SimpleTime.ino

Relógio do sistema ESP32:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/system_time.html

Biblioteca MFRC522:
https://github.com/miguelbalboa/rfid

Importação de CSV UTF-8 no Excel:
https://support.microsoft.com/en-us/excel/opening-csv-utf-8-files-correctly-in-excel
